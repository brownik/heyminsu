from unittest import result
from flask import Flask # 플라스크 클래스 임포트
from flask import request, redirect
import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import Normalizer

app = Flask(__name__) # 내장변수 name을 이용해 서버를 구동시키는 객체 생성

@app.route("/", methods=["GET",'POST'])
def predict_survived() :
    if request.method == 'POST' :# POST 방식일 경우
        a = request.form["I/E"]
        b = request.form["S/N"]
        c = request.form["F/T"]
        d = request.form["J/P"]
        f = request.form["time"]
        g = request.form["house"]
        h = request.form["person"]
        i = request.form["who"]
        j = request.form["trans"]
        k = request.form["season"]
        l = request.form["one"]
        n = request.form["two"]
        m = request.form["where"]
        dic = (a,b,c,d,g,f,h,i,j,k,l,n,m)
        rd= pd.read_csv("제주도mbti - 복사본.CSV",encoding="cp949")
        y = rd["나만 알고있는 제주도 추천 또는 가고싶은 여행지 ( 1 순위 )"]
        X =rd.loc[:,"I/E":"제주의 어느쪽으로 여행을 가고싶은지!"]
        X.loc[-1] = dic
        X.index = X.index + 1
        X = X.sort_index()
        x_one_hot = pd.get_dummies(X)
        sample_one_hot = x_one_hot.iloc[[-1]]
        x_one_hot.drop(x_one_hot.index[0],inplace=True)
        tree_model = DecisionTreeClassifier()
        tree_model.fit(x_one_hot,y)
        pre = tree_model.predict(sample_one_hot)
        #df = df.drop(df[df["나만 알고있는 제주도 추천 또는 가고싶은 여행지 ( 1 순위 )"]==str(pre[0])].index)
        X_train, X_test, y_train, y_test = train_test_split(x_one_hot,y,
                                                    test_size=0.25)
                                                   
        norm = Normalizer()
        X_train_scaled = norm.fit_transform(X_train)
        X_test_scaled = norm.transform(X_test)
        tree_model.fit(X_train_scaled, y_train)
        print('모델의 정확도 :', round(tree_model.score(X_test_scaled, y_test), 4))
        pre1 = tree_model.predict(sample_one_hot)
        
        from sklearn.preprocessing import StandardScaler

        std = StandardScaler()
        std.fit(X_train)
        X_train_scaled = std.transform(X_train)
        X_test_scaled = std.transform(X_test)
        tree_model.fit(X_train_scaled, y_train)
        print('모델의 정확도 :', round(tree_model.score(X_test_scaled, y_test), 4))
        pre2 = tree_model.predict(sample_one_hot)
        
        knn = KNeighborsClassifier(n_neighbors=10)
        knn.fit(X_train, y_train)
        pre3 = knn.predict(sample_one_hot)
        result =[]
        arr =[]
        result.append(pre)
        result.append(pre1)
        result.append(pre2)
        result.append(pre3)
        for value in arr:
            if value not in result:
                result.append(value)

        print(result)

        if len(result) ==1:    
            return redirect("http://localhost:8085/MyMap.jsp?dic="+result[0])
        elif len(result) ==2:
            return redirect("http://localhost:8085/MyMap.jsp?dic="+result[0]+"&dic1="+result[1])
        elif len(result) ==3:
            return redirect ("http://localhost:8085/MyMap.jsp?dic="+result[0]+"&dic1="+result[1]+"&dic2="+result[2])
    
    else : # GET 방식일 경우
        # 넘어온 값을 전처리
        return "어서오세요2."

if __name__ == "__main__" : # .py 파일에서 main함수 역할
    app.run(host="localhost", port="9000") # 9000번 포트로 서버 구동
    